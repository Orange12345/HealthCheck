package com.kpmg.integrations.health;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MockValidatorHealthSource implements HealthCheckSource {

	@Override
	public HealthCheckMessage getHealth() {
		return null;
	}

}

