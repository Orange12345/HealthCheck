package com.kpmg.integrations.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.eclipse.microprofile.health.HealthCheckResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HealthCheckMessageCollatorTest {

	private static final String TEST_SERVICE = "Test service";
	HealthCheckMessageCollator collator;
	HealthCheckMessage knownGood = new HealthCheckMessage(Boolean.TRUE,"TDS","UP");
	HealthCheckMessage knownBad = new HealthCheckMessage(Boolean.FALSE,"FOO","DOWN");

	@BeforeEach
	void setUp() throws Exception {
		collator=new HealthCheckMessageCollator();
	}

	@Test
	void testKnownGood() {
		assertTrue(collator.getUp());
		collator.addMessage(knownGood);
		assertTrue(collator.getUp());
		HealthCheckResponse response = collator.createResponse(TEST_SERVICE);
		assertEquals(TEST_SERVICE,response.getName());
		assertTrue(collator.getUp());
		System.out.println(response.getStatus());
		System.out.println(response.getData());
	}
	
	@Test
	void testKnownBad() {
		assertTrue(collator.getUp());
		collator.addMessage(knownBad);
		collator.addMessage(knownGood);
		assertFalse(collator.getUp());
		HealthCheckResponse response = collator.createResponse(TEST_SERVICE);
		assertEquals(TEST_SERVICE,response.getName());
		
		System.out.println(response.getStatus());
		System.out.println(response.getData());
	}

}
