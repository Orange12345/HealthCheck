package com.kpmg.integrations.health;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MockTDSHealthSource implements HealthCheckSource {

	@Override
	public HealthCheckMessage getHealth() {
		return null;
	}

}

