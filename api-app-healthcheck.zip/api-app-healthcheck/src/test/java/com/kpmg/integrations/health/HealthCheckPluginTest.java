package com.kpmg.integrations.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import javax.enterprise.inject.Any;
import javax.inject.Inject;

import org.eclipse.microprofile.health.HealthCheckResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.mockito.InjectMock;

@QuarkusTest
class HealthCheckPluginTest {
	@InjectMock
	MockTDSHealthSource tdsHealthSource;
	
	@InjectMock
	MockValidatorHealthSource validatorHealthSource;
	
	@Inject
	@Any
	HealthCheckPlugin plugin;

	@BeforeEach
	public void setup() {
		when(validatorHealthSource.getHealth()).thenReturn(new HealthCheckMessage(Boolean.FALSE, "Validator", "DOWN"));
		when(tdsHealthSource.getHealth()).thenReturn(new HealthCheckMessage(Boolean.TRUE, "TDS", "UP"));
	
	}

	@Test
	void testGood() {
		
		//Verify the healthSource is working...
		HealthCheckMessage message = tdsHealthSource.getHealth();
		assertNotNull(message);
		System.out.println(message);
		
		
		HealthCheckResponse response = plugin.call();
		assertNotNull(response);

		assertEquals(HealthCheckResponse.Status.DOWN,response.getStatus());
		System.out.println(response.getStatus());
		System.out.println(response.getData());
	}


}
