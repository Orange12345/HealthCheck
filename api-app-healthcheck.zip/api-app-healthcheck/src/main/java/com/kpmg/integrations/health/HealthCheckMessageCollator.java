package com.kpmg.integrations.health;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.HealthCheckResponseBuilder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HealthCheckMessageCollator{

	List<HealthCheckMessage> messages = new ArrayList<HealthCheckMessage>();
	Boolean up=Boolean.TRUE;
	
	public HealthCheckResponse createResponse(String name) {
		final HealthCheckResponseBuilder responseBuilder;
		if(up) 
			responseBuilder=HealthCheckResponse.named(name).up();
		else
			responseBuilder=HealthCheckResponse.named(name).down();
		
		messages.forEach(message->responseBuilder.withData(message.messageKey, message.messageValue));
		return responseBuilder.build();
	}
	
	public void addMessage(HealthCheckMessage message) {
		up=up&&message.getUp();
		messages.add(message);
	}

}
