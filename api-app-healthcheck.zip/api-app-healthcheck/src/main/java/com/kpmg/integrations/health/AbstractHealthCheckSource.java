package com.kpmg.integrations.health;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class AbstractHealthCheckSource implements HealthCheckSource{

	protected State state=State.DOWN;
	protected String message;
	protected String messageValue;
	
	public AbstractHealthCheckSource(String message) {
		this.message=message;
	}
	//Default behavior is to use the stateStr to indicate up/down but can be changed by a different
	//implemetnation of the HealthCheckSource
	@Override
	public HealthCheckMessage getHealth() {
			return new HealthCheckMessage(state.isUp,message,state.stateStr);
	}
	
	
	//TODO Should the set up/down and isUp be on the HealthCheckSource interface????
	public void setUp() {
		this.state=State.UP;
	}
	
	public void setDown() {
		this.state=State.DOWN;
	}
	

	public Boolean isUp() {
		return this.state.isUp;
	}

}
