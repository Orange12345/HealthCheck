package com.kpmg.integrations.health;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HealthCheckMessage {
	
	public Boolean up=Boolean.FALSE;
	public String messageKey;
	public String messageValue;
	public HealthCheckMessage() {}
	public HealthCheckMessage(Boolean up, String messageKey, String messageValue) {
		super();
		this.up = up;
		this.messageKey = messageKey;
		this.messageValue = messageValue;
	}

	
}
