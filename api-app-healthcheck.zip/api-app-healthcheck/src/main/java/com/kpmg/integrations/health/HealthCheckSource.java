package com.kpmg.integrations.health;

public interface HealthCheckSource {

	public enum State{
		UP(Boolean.TRUE,"UP"),
		DOWN(Boolean.FALSE, "DOWN");
		public final Boolean isUp;
		public final String stateStr;
		State(Boolean up, String stateStr) {
			this.isUp=up;
			this.stateStr=stateStr;
		}
	}
	public HealthCheckMessage getHealth();
}
