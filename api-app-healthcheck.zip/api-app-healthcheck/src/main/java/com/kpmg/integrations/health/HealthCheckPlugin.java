package com.kpmg.integrations.health;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Liveness;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Liveness
@ApplicationScoped
@Getter
@Setter
@ToString
public class HealthCheckPlugin implements HealthCheck{

	@Inject
	@Any
	Instance<HealthCheckSource> healthCheckSources;
	
	@ConfigProperty(name = "service.name", defaultValue = "default")
	String serviceName;
	
	@Override
	public HealthCheckResponse call() {
		HealthCheckMessageCollator collator = new HealthCheckMessageCollator();
		healthCheckSources.forEach(healthCheckSource->collator.addMessage(healthCheckSource.getHealth()));
		return collator.createResponse(serviceName);
	}

}
