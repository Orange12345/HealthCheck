© 2022 KPMG LLP, a Delaware limited liability partnership and a member firm of the KPMG global organization of independent member firms affiliated with KPMG International Limited, a private English company limited by guarantee. All rights reserved.

# api-app-healthcheck Project

This project uses Quarkus, the Supersonic Subatomic Java Framework.

This project contains HealthCheck Plugin and it will be packaged and installed as a dependency

If you want to learn more about Quarkus, please visit its website: https://quarkus.io/ .

## Packaging and installing to the Maven local repository

The project can be packaged and installed using:
```shell script
mvn clean install
```

It produces `api-healthcheck-x.x.x.jar` and `api-healthcheck-x.x.x-sources.jar` files in the target directory.
The package will be installed on the Maven local repository 

## Access Installed Dependency

Developers are able to access the deployed "jar" file by declaring below dependency tag in their `pom.xml` file
```shell script
<dependency>
      <groupId>com.kpmg.krisc</groupId>
      <artifactId>api-healthcheck</artifactId>
      <version>1.0.0-SNAPSHOT</version>
 </dependency>
```
## Related Guides

- RESTEasy Classic ([guide](https://quarkus.io/guides/resteasy)): REST endpoint framework implementing JAX-RS and more
